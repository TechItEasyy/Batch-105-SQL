package com.bank.management.system.customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CustomerDetails implements CustomerDetailsInterface{

	@Override
	public void withdraw(int userId, double amount, Connection conn) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deposit(int userId, double amount, Connection conn) {
		String depositbalance = "update UserAccountDetail set accountBal = accountBal + ? where userId = ?";
		
		try {
			PreparedStatement pst = conn.prepareStatement(depositbalance);
			pst.setDouble(1, amount);
			pst.setInt(2, userId);
			
			int updated = pst.executeUpdate();
			
			if(updated > 0) {
				System.out.println("User amount deposited");
			}else {
				System.out.println("User amount not deposited");
				return;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
}
