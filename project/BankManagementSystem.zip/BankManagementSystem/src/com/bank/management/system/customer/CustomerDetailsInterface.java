package com.bank.management.system.customer;

import java.sql.Connection;

public interface CustomerDetailsInterface {
	public void withdraw(int userId, double amount, Connection conn);
	public void deposit(int userId, double amount,Connection conn);
}
