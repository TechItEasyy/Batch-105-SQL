package com.bank.management.system.admin;

import java.sql.Connection;

public interface AdminDetailInterface {
	public void createAccountMethod(String bankName, String location, String userName, double initialBalance, String role, Connection conn); 
	public void deleteAccountMethod(int userId, Connection conn);
}
