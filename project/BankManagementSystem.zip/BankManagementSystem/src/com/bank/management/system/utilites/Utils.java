package com.bank.management.system.utilites;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Utils {
	static final String DB_URL = "jdbc:mysql://localhost:3306/batch_105";
	static final String USER = "root";
	static final String PASS = "rootroot";
	
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(DB_URL,USER,PASS);
			
			if(con.isClosed()) {
				System.out.println("Could not stablish connection");
			}else {
				System.out.println("Connection stablished");
			}

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;

	}
}
