package com.bank.management.system.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.bank.management.system.admin.AdminDetails;
import com.bank.management.system.customer.CustomerDetails;
import com.bank.management.system.utilites.Utils;

public class BankManagementSystem {

	public static void main(String[] args) {
		Connection conn = Utils.getConnection();
		
		int userId, password;
		String role = null;
		int choice;
		
		String userName, location, bankName;
		
		double initialBalance;
		
		double userAmout;
		
		String selectRoleQuery = "select role from LoginDetail where UserId = ? and CustPass= ?";
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please login..");
		
		System.out.println("Enter User Id");
		userId = sc.nextInt();
		
		System.out.println("Enter Password");
		password = sc.nextInt();
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(selectRoleQuery);
			pstmt.setInt(1, userId);
			pstmt.setInt(2, password);
			
			ResultSet rs = pstmt.executeQuery();
			
			if(rs.next()) {
				role = rs.getString(1);
			}

			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(role.equalsIgnoreCase("Admin")) {
			System.out.println("Welcome Admin");
			
			System.out.println("Would you like to\n Create account: 1\n Delete an account: 2 \n Logout 0");
			
			choice = sc.nextInt();
			
			switch(choice){
				case 1:
					
					System.out.println("Enter Bank Name");
					bankName = sc.next();
					
					System.out.println("Enter location");
					location = sc.next();
					
					
					System.out.println("Enter User Name");
					userName = sc.next();
					
					System.out.println("Enter Initial Balance");
					initialBalance = sc.nextDouble();
					
					System.out.println("Enter Initial Role");
					role = sc.next();
					
					AdminDetails ad = new AdminDetails();
					
					ad.createAccountMethod(bankName,location,userName,initialBalance,role,conn);
					
					
					break;
					
				case 2:
					
					System.out.println("Enter User Id");
					userId = sc.nextInt();
					
					AdminDetails add = new AdminDetails();
					
					add.deleteAccountMethod(userId, conn);
					
					
					break;
					
				case 0:
					
					
					break;
					
					
				default:
					
					
			}
			
		}else if(role.equalsIgnoreCase("User")){
			System.out.println("Welcome User");
			System.out.println("Would you like to\n Deposit: 1\n Widthdraw: 2 \n Logout 0");
			choice = sc.nextInt();
			
			switch(choice){
				case 1:
					
					System.out.println("Enter Amount to be depoited");
					userAmout = sc.nextDouble();
					
					CustomerDetails cd = new CustomerDetails();
					
					cd.deposit(userId, userAmout, conn);
					
					break;
					
				case 2:
					
					System.out.println("Enter User Id");
					userId = sc.nextInt();
					
					AdminDetails add = new AdminDetails();
					
					add.deleteAccountMethod(userId, conn);
					
					
					break;
					
				case 0:
					
					
					break;
					
					
				default:
					
					
			}
			
		}else {
			System.out.println("Invalid User Id and Password");
		}
		
		

	}

}
